Pasta com o objetivo de armazenar conte�do extra ao projeto. 

Sendo ele de car�ter de documenta��o, arquivos de apoio, diagramas e/ou estudo de linguanges vinculadas ao projeto.