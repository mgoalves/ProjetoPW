# ProjetoPW

Projeto da turma de Programa��o para Web.
Alunos: 
Hittalo Flavyo
Jones Quito
Marcello Alves
Reinaldo Albernaz

## Para rodar o projeto

### Para fazer clone.

`git clone https://github.com/mgoalves/ProjetoPW

### Para rodar com o Tomcat.

`mvnw tomcat7:run`

Para rodar com o Tomcat ignorando as configura��es do plugin no `pom.xml`.

`mvnw org.apache.tomcat.maven:tomcat7-maven-plugin:run`

## Para acessar a aplica��o

`http://localhost:9090/PROJETO-DE-PW` em qualquer navegador.