$(document).ready(function() { 
	window.location.href='#conteudo';
});