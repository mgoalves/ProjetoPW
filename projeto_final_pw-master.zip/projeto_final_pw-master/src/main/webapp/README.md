# ProjetoPW
Trabalho em Grupo - Disciplina Projeto de Software - SI 2017-1

## Criação do diretório de includes (em 17 de maio de 2017 - Jones Quito)
- Dentro do diretório foi criada uma página jsp com o rodapé do sistema que é comum a todas as páginas
- Dentro do diretório de includes foram criados, também, dois subdiretórios, <br/>
um para os includes referentes as páginas de controle de professores e outro para as páginas de controle de alunos.
- Cada diretório contém um include de cabeçalho e outro para a faixa de opções (botões e controle do topo da página);
