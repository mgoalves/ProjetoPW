package br.com.labpw.model.disciplina;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DisciplinaEditar implements LogicaDisciplina{
	
	public String executa(HttpServletRequest request, HttpServletResponse response) throws Exception{
		return null;
	}

}
