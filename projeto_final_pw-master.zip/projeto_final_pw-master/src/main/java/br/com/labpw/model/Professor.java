package br.com.labpw.model;

public class Professor {
	
	String rg;
	String cpf;
	String nome;
	int matricula;
	String dataNascimento;
	
	Endereco end;
	
	Formacao form;
	

}
