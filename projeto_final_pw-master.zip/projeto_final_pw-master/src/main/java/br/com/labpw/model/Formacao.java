package br.com.labpw.model;

public class Formacao {
	
	String mestrado;
	String graduacao;
	String posGraduacao;
	

}
