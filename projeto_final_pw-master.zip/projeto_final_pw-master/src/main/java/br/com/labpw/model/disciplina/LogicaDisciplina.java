package br.com.labpw.model.disciplina;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface LogicaDisciplina {
	
	String executa(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
}
