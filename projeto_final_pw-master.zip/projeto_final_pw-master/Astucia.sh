gnome-open http://localhost:9090/PROJETO-DE-PW/
mvn tomcat7:run
